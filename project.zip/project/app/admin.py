from django.contrib import admin

# Register your models here.

# USED TO REPRESENT THE MODEL IN ADMIN PANEL....
